# Brent W. Williams
# DS785: Data Science Capstone
# Dr. Garland
# TWEET TEXT CLEANING SCRIPT

###########################################################################################
# Clear the memory and console:
rm(list=ls())
gc()
cat("\014")  #clear the console
################################################ 



################################################ READ IN THE TWEETS
# Set the working directory containing the tweets:
setwd("C:/TextAnalytics/")

# Read the harvested tweets in:
tweet_polaris_data = read.csv("Combined_Polaris_tweets.csv")
tweet_atv_data = read.csv("Combined_ATV_tweets.csv")
tweet_utv_data = read.csv("Combined_UTV_tweets.csv")
#tweet_sxs_data = read.csv("Combined_SXS_tweets.csv")   #removed from study due to ~500 tweets total

# Split off the tweet content from the records:
tweet_polaris_data = tweet_polaris_data[2]
tweet_atv_data = tweet_atv_data[2]
tweet_utv_data = tweet_utv_data[2]

# Find the total number of posts 
# for each data set:
length(tweet_polaris_data[[1]])
length(tweet_atv_data[[1]])
length(tweet_utv_data[[1]])
################################################ END OF READING IN DATA


################################################ SAMPLE THE TWEETS
# Because the number of tweets is uneven we need to ensure
# each category has approximately the same representation of tweet content
# Sample 4000 records and save as a new variable for each population:
set.seed(123)
samp_tweet_polaris_data = sample(tweet_polaris_data[[1]], 4000)
samp_tweet_atv_data = sample(tweet_atv_data[[1]], 4000)
samp_tweet_utv_data = sample(tweet_utv_data[[1]], 4000)


# Ensure the post lengths for each 
# data set is 4000 records:
length(samp_tweet_polaris_data)
length(samp_tweet_atv_data)
length(samp_tweet_utv_data)

# Write our preclean results and clean up memory:
setwd("C:/TextAnalytics")
write.csv(samp_tweet_polaris_data, "preclean_tweet_polaris.csv")
write.csv(samp_tweet_atv_data, "preclean_tweet_atv.csv")
write.csv(samp_tweet_utv_data, "preclean_tweet_utv.csv")

# Clear variables in memory:
rm(list=ls())
gc()
cat("\014")  #clear the console
################################################ END OF POST SAMPLING




################################################ CLEANING EACH TEXT POPULATION
# Load the supporting libraries:
library(tm)
library(stringr)

# Additional stopwords with which to clean text:
mystopwords = c("just","click","will","like","said","use",
                "get","one","now","see","put","got","know","don",
                "also","take","expand","didn","come","say","may",
                "seem","com","guy","can","cat","think","thank","sent",
                "polari","atv","utv","shit","fuck","fucking","damn","bitch")

# Create a function to load files in as a corpus:
createCorpus <- function(filepath) {
  conn <- file(filepath, "r")
  fulltext <- readLines(conn)
  close(conn)
  
  vs <- VectorSource(fulltext)
  Corpus(vs, readerControl=list(readPlain, language="en", load=TRUE))
}

# Set the working directory containing the preclean data:
setwd("C:/TextAnalytics")

################################# POLARIS TWEETS BEGIN
# Read in the precleaned data, merge into one vector, apply lowercase adjustment,
# remove mentions, urls, emojis, numbers and punctuation (first pass):
text = read.csv("preclean_tweet_polaris.csv")
text = tolower(text)
text = gsub("@\\w+", " ", text)
text = gsub("\\d+\\w*\\d*", " ", text)
text = gsub("#\\w+", " ", text)
text = gsub("[^\x01-\x7F]", " ", text)
text = gsub("[[:punct:]]", " ", text)
text = gsub("(http[^ ]*)|(www.[^ ]*)", "", text)
text = paste(Filter(function(x) nchar(x) > 1, unlist(strsplit(text, " "))), collapse=" ")

# Write to CSV file, reload as corpus:
write.csv(text, "cleaned_tweet_polaris.csv", row.names=FALSE)
rm(text)
text = createCorpus("C:/TextAnalytics/cleaned_tweet_polaris.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
tweet_polaris_corpus = text
################################# POLARIS TWEETS END

################################# ATV TWEETS BEGIN
# Read in the precleaned data, merge into one vector, apply lowercase adjustment,
# remove mentions, urls, emojis, numbers and punctuation (first pass):
text = read.csv("preclean_tweet_atv.csv")
text = tolower(text)
text = gsub("@\\w+", " ", text)
text = gsub("\\d+\\w*\\d*", " ", text)
text = gsub("#\\w+", " ", text)
text = gsub("[^\x01-\x7F]", " ", text)
text = gsub("[[:punct:]]", " ", text)
text = gsub("(http[^ ]*)|(www.[^ ]*)", "", text)
text = paste(Filter(function(x) nchar(x) > 1, unlist(strsplit(text, " "))), collapse=" ")

# Write to CSV file, reload as corpus:
write.csv(text, "cleaned_tweet_atv.csv", row.names=FALSE)
rm(text)
text = createCorpus("C:/TextAnalytics/cleaned_tweet_atv.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
tweet_atv_corpus = text
################################# ATV TWEETS END

################################# UTV TWEETS BEGIN
# Read in the precleaned data, merge into one vector, apply lowercase adjustment,
# remove mentions, urls, emojis, numbers and punctuation (first pass):
text = read.csv("preclean_tweet_utv.csv")
text = tolower(text)
text = gsub("@\\w+", " ", text)
text = gsub("\\d+\\w*\\d*", " ", text)
text = gsub("#\\w+", " ", text)
text = gsub("[^\x01-\x7F]", " ", text)
text = gsub("[[:punct:]]", " ", text)
text = gsub("(http[^ ]*)|(www.[^ ]*)", "", text)
text = paste(Filter(function(x) nchar(x) > 1, unlist(strsplit(text, " "))), collapse=" ")

# Write to CSV file, reload as corpus:
write.csv(text, "cleaned_tweet_utv.csv", row.names=FALSE)
rm(text)
text = createCorpus("C:/TextAnalytics/cleaned_tweet_utv.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
tweet_utv_corpus = text
################################# UTV TWEETS END
################################################ CLEANING END



################################################ SIMPLE DESCRIPTIVE STATISTICS & WORD FREQUENCIES
# Load supporting libraries:
library(tm)
library(ggplot2)

################################# POLARIS TWEETS BEGIN
# Create a document-term matrix where each document is a post:
dtm = DocumentTermMatrix(tweet_polaris_corpus)

# Number of unique words in the corpus:
freq = colSums(as.matrix(dtm))   
length(freq)

# Calculate word frequency and display the top 20 words of the corpus:
freq = sort(colSums(as.matrix(dtm)), decreasing=TRUE)   
wf = data.frame(Term = names(freq), Count = freq)   
head(wf, 20)

# Calculate the total number of words in the corpus:
sum(wf$Count)

# Plot the word frequencies of words mentioned over 500 times across the sampled posts:
plot = ggplot(subset(wf, freq>100), aes(x = reorder(Term, -Count), y = Count)) +
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle=45, hjust=1)) +
  geom_text(aes(label=Count), position=position_dodge(width=0.9), vjust=-0.25) +
  xlab("Word") +
  theme(axis.text.x = element_text(size = 18)) +
  ylim(0,1000)

plot
################################# POLARIS TWEETS END

################################# ATV TWEETS BEGIN
# Create a document-term matrix where each document is a post:
dtm = DocumentTermMatrix(tweet_atv_corpus)

# Number of unique words in the corpus:
freq = colSums(as.matrix(dtm))   
length(freq)

# Calculate word frequency and display the top 20 words of the corpus:
freq = sort(colSums(as.matrix(dtm)), decreasing=TRUE)   
wf = data.frame(Term = names(freq), Count = freq)   
head(wf, 20)

# Calculate the total number of words in the corpus:
sum(wf$Count)

# Plot the word frequencies of words mentioned over 500 times across the sampled posts:
plot = ggplot(subset(wf, freq>100), aes(x = reorder(Term, -Count), y = Count)) +
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle=45, hjust=1)) +
  geom_text(aes(label=Count), position=position_dodge(width=0.9), vjust=-0.25) +
  xlab("Word") +
  theme(axis.text.x = element_text(size = 18)) +
  ylim(0,1000)

plot
################################# ATV TWEETS END

################################# UTV TWEETS BEGIN
# Create a document-term matrix where each document is a post:
dtm = DocumentTermMatrix(tweet_utv_corpus)

# Number of unique words in the corpus:
freq = colSums(as.matrix(dtm))   
length(freq)

# Calculate word frequency and display the top 20 words of the corpus:
freq = sort(colSums(as.matrix(dtm)), decreasing=TRUE)   
wf = data.frame(Term = names(freq), Count = freq)   
head(wf, 20)

# Calculate the total number of words in the corpus:
sum(wf$Count)

# Plot the word frequencies of words mentioned over 500 times across the sampled posts:
plot = ggplot(subset(wf, freq>100), aes(x = reorder(Term, -Count), y = Count)) +
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle=45, hjust=1)) +
  geom_text(aes(label=Count), position=position_dodge(width=0.9), vjust=-0.25) +
  xlab("Word") +
  theme(axis.text.x = element_text(size = 18)) +
  ylim(0,1000)

plot
################################# UTV TWEETS END
################################################ SIMPLE DESCRIPTIVE STATS END



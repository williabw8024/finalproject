# Brent W. Williams
# DS785: Data Science Capstone
# Dr. Garland
# FORUM TEXT ANALYSIS SCRIPT

################################################ READ IN THE CLEANED DATA AND PREPARE IT FOR ANALYSIS
# Clear the memory and console:
rm(list=ls())
gc()
cat("\014")  #clear the console

# Load supporting libraries:
library(tm)

# Additional stopwords with which to clean text:
mystopwords = c("just","click","will","like","said","use",
                "get","one","now","see","put","got","know","don",
                "also","take","expand","didn","come","say","may",
                "seem","com","guy","can","cat","think","thank","sent")

# Create a function to load files in as a corpus:
createCorpus <- function(filepath) {
  conn <- file(filepath, "r")
  fulltext <- readLines(conn)
  close(conn)
  vs <- VectorSource(fulltext)
  Corpus(vs, readerControl=list(readPlain, language="en", load=TRUE))
}

# Set the working directory containing the preclean data:
setwd("C:/TextAnalytics")

################################# POLARIS ATV BEGIN
# Read in data as corpus:
text = createCorpus("C:/TextAnalytics/cleaned_polaris_atv.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
polaris_atv_corpus = text
rm(text)
################################# POLARIS ATV END

################################# POLARIS SXS BEGIN
# Read in data as corpus:
text = createCorpus("C:/TextAnalytics/cleaned_polaris_sxs.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
polaris_sxs_corpus = text
rm(text)
################################# POLARIS SXS END

################################# CAN-AM ATV BEGIN
# Read in data as corpus:
text = createCorpus("C:/TextAnalytics/cleaned_canam_atv.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
canam_atv_corpus = text
rm(text)
################################# CAN-AM ATV END

################################# CAN-AM SXS BEGIN
# Read in data as corpus:
text = createCorpus("C:/TextAnalytics/cleaned_canam_sxs.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
canam_sxs_corpus = text
rm(text)
################################# CAN-AM SXS END

################################# ARCTIC CAT ATV BEGIN
# Read in data as corpus:
text = createCorpus("C:/TextAnalytics/cleaned_arcat_atv.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
arcat_atv_corpus = text
rm(text)
################################# ARCTIC CAT ATV END

################################# ARCTIC CAT SXS BEGIN
# Read in data as corpus:
text = createCorpus("C:/TextAnalytics/cleaned_arcat_sxs.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
arcat_sxs_corpus = text
rm(text)
################################# ARCTIC CAT SXS END
################################################ DATA LOAD END



############################################## WORDCLOUDS
library(tm)
library(wordcloud)
library(RColorBrewer)
# Wordcloud for Polaris ATV:
tdm = TermDocumentMatrix(polaris_atv_corpus)
matrix = as.matrix(tdm)
words = sort(rowSums(matrix),decreasing=TRUE) 
df = data.frame(word = names(words),freq=words)
set.seed(8675309) # for reproducibility
par(bg = 'black')
wordcloud(words = df$word, freq = df$freq, 
          min.freq = 100, max.words=100, random.order=FALSE, 
          rot.per=0.35, colors=brewer.pal(8, "Dark2"))
# Note: if warnings are displayed, enlarge the plot area

# Wordcloud for Polaris SXS:
tdm = TermDocumentMatrix(polaris_sxs_corpus)
matrix = as.matrix(tdm)
words = sort(rowSums(matrix),decreasing=TRUE) 
df = data.frame(word = names(words),freq=words)
set.seed(8675309) # for reproducibility
par(bg = 'black')
wordcloud(words = df$word, freq = df$freq, 
          min.freq = 100, max.words=100, random.order=FALSE, 
          rot.per=0.35, colors=brewer.pal(8, "Dark2"))
# Note: if warnings are displayed, enlarge the plot area

# Wordcloud for Can-Am ATV:
tdm = TermDocumentMatrix(canam_atv_corpus)
matrix = as.matrix(tdm)
words = sort(rowSums(matrix),decreasing=TRUE) 
df = data.frame(word = names(words),freq=words)
set.seed(8675309) # for reproducibility
par(bg = 'black')
wordcloud(words = df$word, freq = df$freq, 
          min.freq = 100, max.words=100, random.order=FALSE, 
          rot.per=0.35, colors=brewer.pal(8, "Dark2"))
# Note: if warnings are displayed, enlarge the plot area

# Wordcloud for Can-Am SXS:
tdm = TermDocumentMatrix(canam_sxs_corpus)
matrix = as.matrix(tdm)
words = sort(rowSums(matrix),decreasing=TRUE) 
df = data.frame(word = names(words),freq=words)
set.seed(8675309) # for reproducibility
par(bg = 'black')
wordcloud(words = df$word, freq = df$freq, 
          min.freq = 100, max.words=100, random.order=FALSE, 
          rot.per=0.35, colors=brewer.pal(8, "Dark2"))
# Note: if warnings are displayed, enlarge the plot area

# Wordcloud for Arctic Cat ATV:
tdm = TermDocumentMatrix(arcat_atv_corpus)
matrix = as.matrix(tdm)
words = sort(rowSums(matrix),decreasing=TRUE) 
df = data.frame(word = names(words),freq=words)
set.seed(8675309) # for reproducibility 
par(bg = 'black')
wordcloud(words = df$word, freq = df$freq, 
          min.freq = 100, max.words=100, random.order=FALSE, 
          rot.per=0.35, colors=brewer.pal(8, "Dark2"))
# Note: if warnings are displayed, enlarge the plot area

# Wordcloud for Arctic Cat SXS:
tdm = TermDocumentMatrix(arcat_sxs_corpus)
matrix = as.matrix(tdm)
words = sort(rowSums(matrix),decreasing=TRUE) 
df = data.frame(word = names(words),freq=words)
set.seed(8675309) # for reproducibility
par(bg = 'black')
wordcloud(words = df$word, freq = df$freq, 
          min.freq = 100, max.words=100, random.order=FALSE, 
          rot.per=0.35, colors=brewer.pal(8, "Dark2"))
# Note: if warnings are displayed, enlarge the plot area
############################################## WORDCLOUDS END



############################################## TOPIC MODELING
# Clear the memory and console:
rm(list=ls())
gc()
cat("\014")  #clear the console
 
# Load the supporting libraries:
library(tm)
library(topicmodels)
library(tidytext)
library(ggplot2)
library(dplyr)

# Additional stopwords with which to clean text:
mystopwords = c("just","click","will","like","said","use",
                "get","one","now","see","put","got","know","don",
                "also","take","expand","didn","come","say","may",
                "seem","com","guy","can","cat","think","thank","sent")

# Create subfolders which will be used to store files for corpus loadings:
setwd("C:/TextAnalytics")
dir.create("polaris")
dir.create("canam")
dir.create("arcticcat")
setwd("C:/TextAnalytics/polaris")
dir.create("atv")
dir.create("sxs")
setwd("C:/TextAnalytics/canam")
dir.create("atv")
dir.create("sxs")
setwd("C:/TextAnalytics/arcticcat")
dir.create("atv")
dir.create("sxs")

# Copy the cleaned files (from text cleaning script) to their respective subfolders:
file.copy(from = "C:/TextAnalytics/cleaned_polaris_atv.csv", to = "C:/TextAnalytics/polaris/atv/cleaned_polaris_atv.csv")
file.copy(from = "C:/TextAnalytics/cleaned_polaris_sxs.csv", to = "C:/TextAnalytics/polaris/sxs/cleaned_polaris_sxs.csv")
file.copy(from = "C:/TextAnalytics/cleaned_canam_atv.csv", to = "C:/TextAnalytics/canam/atv/cleaned_canam_atv.csv")
file.copy(from = "C:/TextAnalytics/cleaned_canam_sxs.csv", to = "C:/TextAnalytics/canam/sxs/cleaned_canam_sxs.csv")
file.copy(from = "C:/TextAnalytics/cleaned_arcat_atv.csv", to = "C:/TextAnalytics/arcticcat/atv/cleaned_arcat_atv.csv")
file.copy(from = "C:/TextAnalytics/cleaned_arcat_sxs.csv", to = "C:/TextAnalytics/arcticcat/sxs/cleaned_arcat_sxs.csv")

################################### POLARIS ATV BEGIN
# Read in the corpus
text = Corpus(DirSource("C:/TextAnalytics/polaris/atv"))

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
polaris_atv_corpus = text
corp1 = DocumentTermMatrix(polaris_atv_corpus)

# Create Latent Dirichlet Allocation model, 3 topics, set seed for reproducibility:
corp1_lda <- LDA(corp1, k = 3, control = list(seed = 8675309))

# Create a tibble with beta (per topic, per word probability):
corp1_topics = tidy(corp1_lda, matrix = "beta")

# Plot the topics by top 10 terms in them:
corp1_top_terms <- corp1_topics %>%
  group_by(topic) %>%
  top_n(10, beta) %>%
  ungroup() %>%
  arrange(topic, -beta)

corp1_top_terms %>%
  mutate(term = reorder_within(term, beta, topic)) %>%
  ggplot(aes(beta, term, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free") +
  scale_y_reordered() +
  theme(axis.text.y = element_text(size=15)) +
  theme(axis.title.y = element_text(size=20)) +
  xlim(0,0.02)
################################### POLARIS ATV END

################################### POLARIS SXS BEGIN
# Read in the corpus
text = Corpus(DirSource("C:/TextAnalytics/polaris/sxs"))

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
polaris_sxs_corpus = text
corp1 = DocumentTermMatrix(polaris_sxs_corpus)

# Create Latent Dirichlet Allocation model, 3 topics, set seed for reproducibility:
corp1_lda <- LDA(corp1, k = 3, control = list(seed = 8675309))

# Create a tibble with beta (per topic, per word probability):
corp1_topics = tidy(corp1_lda, matrix = "beta")

# Plot the topics by top 10 terms in them:
corp1_top_terms <- corp1_topics %>%
  group_by(topic) %>%
  top_n(10, beta) %>%
  ungroup() %>%
  arrange(topic, -beta)

corp1_top_terms %>%
  mutate(term = reorder_within(term, beta, topic)) %>%
  ggplot(aes(beta, term, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free") +
  scale_y_reordered() +
  theme(axis.text.y = element_text(size=15)) +
  theme(axis.title.y = element_text(size=20)) +
  xlim(0,0.02)
################################### POLARIS SXS END

################################### CAN-AM ATV BEGIN
# Read in the corpus
text = Corpus(DirSource("C:/TextAnalytics/canam/atv"))

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
canam_atv_corpus = text
corp1 = DocumentTermMatrix(canam_atv_corpus)

# Create Latent Dirichlet Allocation model, 3 topics, set seed for reproducibility:
corp1_lda <- LDA(corp1, k = 3, control = list(seed = 8675309))

# Create a tibble with beta (per topic, per word probability):
corp1_topics = tidy(corp1_lda, matrix = "beta")

# Plot the topics by top 10 terms in them:
corp1_top_terms <- corp1_topics %>%
  group_by(topic) %>%
  top_n(10, beta) %>%
  ungroup() %>%
  arrange(topic, -beta)

corp1_top_terms %>%
  mutate(term = reorder_within(term, beta, topic)) %>%
  ggplot(aes(beta, term, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free") +
  scale_y_reordered() +
  theme(axis.text.y = element_text(size=15)) +
  theme(axis.title.y = element_text(size=20)) +
  xlim(0,0.02)
################################### CAN-AM ATV END

################################### CAN-AM SXS BEGIN
# Read in the corpus
text = Corpus(DirSource("C:/TextAnalytics/canam/sxs"))

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
canam_sxs_corpus = text
corp1 = DocumentTermMatrix(canam_sxs_corpus)

# Create Latent Dirichlet Allocation model, 3 topics, set seed for reproducibility:
corp1_lda <- LDA(corp1, k = 3, control = list(seed = 8675309))

# Create a tibble with beta (per topic, per word probability):
corp1_topics = tidy(corp1_lda, matrix = "beta")

# Plot the topics by top 10 terms in them:
corp1_top_terms <- corp1_topics %>%
  group_by(topic) %>%
  top_n(10, beta) %>%
  ungroup() %>%
  arrange(topic, -beta)

corp1_top_terms %>%
  mutate(term = reorder_within(term, beta, topic)) %>%
  ggplot(aes(beta, term, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free") +
  scale_y_reordered() +
  theme(axis.text.y = element_text(size=15)) +
  theme(axis.title.y = element_text(size=20)) +
  xlim(0,0.02)
################################### CAN-AM SXS END

################################### ARCTIC CAT ATV BEGIN
# Read in the corpus
text = Corpus(DirSource("C:/TextAnalytics/arcticcat/atv"))

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
arcat_atv_corpus = text
corp1 = DocumentTermMatrix(arcat_atv_corpus)

# Create Latent Dirichlet Allocation model, 3 topics, set seed for reproducibility:
corp1_lda <- LDA(corp1, k = 3, control = list(seed = 8675309))

# Create a tibble with beta (per topic, per word probability):
corp1_topics = tidy(corp1_lda, matrix = "beta")

# Plot the topics by top 10 terms in them:
corp1_top_terms <- corp1_topics %>%
  group_by(topic) %>%
  top_n(10, beta) %>%
  ungroup() %>%
  arrange(topic, -beta)

corp1_top_terms %>%
  mutate(term = reorder_within(term, beta, topic)) %>%
  ggplot(aes(beta, term, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free") +
  scale_y_reordered() +
  theme(axis.text.y = element_text(size=15)) +
  theme(axis.title.y = element_text(size=20)) +
  xlim(0,0.02)
################################### ARCTIC CAT ATV END

################################### ARCTIC CAT SXS BEGIN
# Read in the corpus
text = Corpus(DirSource("C:/TextAnalytics/arcticcat/sxs"))

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
arcat_sxs_corpus = text
corp1 = DocumentTermMatrix(arcat_sxs_corpus)

# Create Latent Dirichlet Allocation model, 3 topics, set seed for reproducibility:
corp1_lda <- LDA(corp1, k = 3, control = list(seed = 8675309))

# Create a tibble with beta (per topic, per word probability):
corp1_topics = tidy(corp1_lda, matrix = "beta")

# Plot the topics by top 10 terms in them:
corp1_top_terms <- corp1_topics %>%
  group_by(topic) %>%
  top_n(10, beta) %>%
  ungroup() %>%
  arrange(topic, -beta)

corp1_top_terms %>%
  mutate(term = reorder_within(term, beta, topic)) %>%
  ggplot(aes(beta, term, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free") +
  scale_y_reordered() +
  theme(axis.text.y = element_text(size=15)) +
  theme(axis.title.y = element_text(size=20)) +
  xlim(0,0.02)
################################### ARCTIC CAT SXS END
############################################## TOPIC MODELING END



############################################## CLUSTERING
# Load the supporting libraries:
library(slam)
library(tm)
library(cluster)

################################### POLARIS ATV BEGIN
# Create a document term matrix of the corpus:
dtm = DocumentTermMatrix(polaris_atv_corpus)

# Find the total occurences of each word:
colTotals <-  col_sums(dtm)

# Keep only words which occur more than 500 times:
dtm2 <- dtm[,which(colTotals >500)]

# Remove sparse terms:
dtmss <- removeSparseTerms(dtm2, 0.15) # This makes a matrix that is only 15% empty space, maximum.   


# Calculate Euclidian distance and fit Ward's model for clustering:
d <- dist(t(dtmss), method="euclidian")   
fit <- hclust(d=d, method="ward.D")
dend = as.dendrogram(fit)
str(dend)

# Plot the dendrogram to display clustering of terms:
par(mar = c(5, 5, 5, 5), bg = 'white') # Set margins for plot
plot(dend, horiz = F, ylab = "Height", xlab = "Term")
################################### POLARIS ATV END

################################### POLARIS SXS BEGIN
# Create a document term matrix of the corpus:
dtm = DocumentTermMatrix(polaris_sxs_corpus)

# Find the total occurences of each word:
colTotals <-  col_sums(dtm)

# Keep only words which occur more than 500 times:
dtm2 <- dtm[,which(colTotals >500)]

# Remove sparse terms:
dtmss <- removeSparseTerms(dtm2, 0.15) # This makes a matrix that is only 15% empty space, maximum.   


# Calculate Euclidian distance and fit Ward's model for clustering:
d <- dist(t(dtmss), method="euclidian")   
fit <- hclust(d=d, method="ward.D")
dend = as.dendrogram(fit)
str(dend)

# Plot the dendrogram to display clustering of terms:
par(mar = c(5, 5, 5, 5)) # Set margins for plot
plot(dend, horiz = F, ylab = "Height", xlab = "Term")
################################### POLARIS SXS END

################################### CAN-AM ATV BEGIN
# Create a document term matrix of the corpus:
dtm = DocumentTermMatrix(canam_atv_corpus)

# Find the total occurences of each word:
colTotals <-  col_sums(dtm)

# Keep only words which occur more than 500 times:
dtm2 <- dtm[,which(colTotals >500)]

# Remove sparse terms:
dtmss <- removeSparseTerms(dtm2, 0.15) # This makes a matrix that is only 15% empty space, maximum.   


# Calculate Euclidian distance and fit Ward's model for clustering:
d <- dist(t(dtmss), method="euclidian")   
fit <- hclust(d=d, method="ward.D")
dend = as.dendrogram(fit)

# Plot the dendrogram to display clustering of terms:
par(mar = c(5, 5, 5, 5)) # Set margins for plot
plot(dend, horiz = F, ylab = "Height", xlab = "Term")
################################### CAN-AM ATV END

################################### CAN-AM SXS BEGIN
# Create a document term matrix of the corpus:
dtm = DocumentTermMatrix(canam_sxs_corpus)

# Find the total occurences of each word:
colTotals <-  col_sums(dtm)

# Keep only words which occur more than 500 times:
dtm2 <- dtm[,which(colTotals >500)]

# Remove sparse terms:
dtmss <- removeSparseTerms(dtm2, 0.15) # This makes a matrix that is only 15% empty space, maximum.   


# Calculate Euclidian distance and fit Ward's model for clustering:
d <- dist(t(dtmss), method="euclidian")   
fit <- hclust(d=d, method="ward.D")
dend = as.dendrogram(fit)

# Plot the dendrogram to display clustering of terms:
par(mar = c(5, 5, 5, 5)) # Set margins for plot
plot(dend, horiz = F, ylab = "Height", xlab = "Term")
################################### CAN-AM SXS END

################################### ARCTIC CAT ATV BEGIN
# Create a document term matrix of the corpus:
dtm = DocumentTermMatrix(arcat_atv_corpus)

# Find the total occurences of each word:
colTotals <-  col_sums(dtm)

# Keep only words which occur more than 500 times:
dtm2 <- dtm[,which(colTotals >500)]

# Remove sparse terms:
dtmss <- removeSparseTerms(dtm2, 0.15) # This makes a matrix that is only 15% empty space, maximum.   


# Calculate Euclidian distance and fit Ward's model for clustering:
d <- dist(t(dtmss), method="euclidian")   
fit <- hclust(d=d, method="ward.D")
dend = as.dendrogram(fit)

# Plot the dendrogram to display clustering of terms:
par(mar = c(5, 5, 5, 5)) # Set margins for plot
plot(dend, horiz = F, ylab = "Height", xlab = "Term")
################################### ARCTIC CAT ATV END

################################### ARCTIC CAT SXS BEGIN
# Create a document term matrix of the corpus:
dtm = DocumentTermMatrix(arcat_sxs_corpus)

# Find the total occurences of each word:
colTotals <-  col_sums(dtm)

# Keep only words which occur more than 500 times:
dtm2 <- dtm[,which(colTotals >500)]

# Remove sparse terms:
dtmss <- removeSparseTerms(dtm2, 0.15) # This makes a matrix that is only 15% empty space, maximum.   


# Calculate Euclidian distance and fit Ward's model for clustering:
d <- dist(t(dtmss), method="euclidian")   
fit <- hclust(d=d, method="ward.D")
dend = as.dendrogram(fit)

# Plot the dendrogram to display clustering of terms:
par(mar = c(5, 5, 5, 5)) # Set margins for plot
plot(dend, horiz = F, ylab = "Height", xlab = "Term")
################################### ARCTIC CAT SXS END
############################################## CLUSTERING END






############################################## SENTIMENT ANALYSIS
# Clear the memory and console:
rm(list=ls())
gc()
cat("\014")  #clear the console

# Load the supporting libraries:
library(tidyverse)
library(tidytext)
library(glue)
library(stringr)
library(reshape2)
library(wordcloud)

################################### POLARIS ATV BEGIN
# Set the working directory, load the file and remove whitespace:
setwd("C:/TextAnalytics")
fileName <- trimws("sentiment_cleaned_polaris_atv.csv")

# Concatenate all posts together:
fileText <- glue(read_file(fileName))

# Remove special symbols, split data into terms and remove empty string data:
fileText <- gsub("\\$", "", fileText)
fileText = strsplit(fileText, " ")
fileText = unlist(fileText)
fileText = fileText[fileText != ""]

# Tokenize the data:
tokens = tibble(text = fileText) %>% unnest_tokens(word, text)

# Get sentiment from the text using the Hu and Liu Lexicon (reference in paper):
tokens %>%
  inner_join(get_sentiments("bing")) %>% # pull out only sentiment words
  count(sentiment) %>% # count the # of positive & negative words
  spread(sentiment, n, fill = 0) %>% # made data wide rather than narrow
  mutate(sentiment = positive / (negative + positive)) # ratio of positive

# Create a summary of positive and negative terms, display the top 20:
term_summary = tokens %>% inner_join(get_sentiments("bing")) %>% count(word, sentiment, sort = TRUE)
head(term_summary, 20)

# Display a negative sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("red", "gray80"),
                   max.words = 100)

# Display a positive sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("gray80", "darkgreen"),
                   max.words = 100)
################################### POLARIS ATV END

################################### POLARIS SXS BEGIN
# Set the working directory, load the file and remove whitespace:
setwd("C:/TextAnalytics/")
fileName <- trimws("sentiment_cleaned_polaris_sxs.csv")

# Concatenate all posts together:
fileText <- glue(read_file(fileName))

# Remove special symbols, split data into terms and remove empty string data:
fileText <- gsub("\\$", "", fileText)
fileText = strsplit(fileText, " ")
fileText = unlist(fileText)
fileText = fileText[fileText != ""]

# Tokenize the data:
tokens = tibble(text = fileText) %>% unnest_tokens(word, text)

# Get sentiment from the text using the Hu and Liu Lexicon (reference in paper):
tokens %>%
  inner_join(get_sentiments("bing")) %>% # pull out only sentiment words
  count(sentiment) %>% # count the # of positive & negative words
  spread(sentiment, n, fill = 0) %>% # made data wide rather than narrow
  mutate(sentiment = positive / (negative + positive)) # ratio of positive

# Create a summary of positive and negative terms, display the top 20:
term_summary = tokens %>% inner_join(get_sentiments("bing")) %>% count(word, sentiment, sort = TRUE)
head(term_summary, 20)

# Display a negative sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("red", "gray80"),
                   max.words = 100)

# Display a positive sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("gray80", "darkgreen"),
                   max.words = 100)
################################### POLARIS SXS END

################################### CAN-AM ATV BEGIN
# Set the working directory, load the file and remove whitespace:
setwd("C:/TextAnalytics")
fileName <- trimws("sentiment_cleaned_canam_atv.csv")

# Concatenate all posts together:
fileText <- glue(read_file(fileName))

# Remove special symbols, split data into terms and remove empty string data:
fileText <- gsub("\\$", "", fileText)
fileText = strsplit(fileText, " ")
fileText = unlist(fileText)
fileText = fileText[fileText != ""]

# Tokenize the data:
tokens = tibble(text = fileText) %>% unnest_tokens(word, text)

# Get sentiment from the text using the Hu and Liu Lexicon (reference in paper):
tokens %>%
  inner_join(get_sentiments("bing")) %>% # pull out only sentiment words
  count(sentiment) %>% # count the # of positive & negative words
  spread(sentiment, n, fill = 0) %>% # made data wide rather than narrow
  mutate(sentiment = positive / (negative + positive)) # ratio of positive

# Create a summary of positive and negative terms, display the top 20:
term_summary = tokens %>% inner_join(get_sentiments("bing")) %>% count(word, sentiment, sort = TRUE)
head(term_summary, 20)

# Display a negative sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("red", "gray80"),
                   max.words = 100)

# Display a positive sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("gray80", "darkgreen"),
                   max.words = 100)
################################### CAN-AM ATV END

################################### CAN-AM SXS BEGIN
# Set the working directory, load the file and remove whitespace:
setwd("C:/TextAnalytics")
fileName <- trimws("sentiment_cleaned_canam_sxs.csv")

# Concatenate all posts together:
fileText <- glue(read_file(fileName))

# Remove special symbols, split data into terms and remove empty string data:
fileText <- gsub("\\$", "", fileText)
fileText = strsplit(fileText, " ")
fileText = unlist(fileText)
fileText = fileText[fileText != ""]

# Tokenize the data:
tokens = tibble(text = fileText) %>% unnest_tokens(word, text)

# Get sentiment from the text using the Hu and Liu Lexicon (reference in paper):
tokens %>%
  inner_join(get_sentiments("bing")) %>% # pull out only sentiment words
  count(sentiment) %>% # count the # of positive & negative words
  spread(sentiment, n, fill = 0) %>% # made data wide rather than narrow
  mutate(sentiment = positive / (negative + positive)) # ratio of positive

# Create a summary of positive and negative terms, display the top 20:
term_summary = tokens %>% inner_join(get_sentiments("bing")) %>% count(word, sentiment, sort = TRUE)
head(term_summary, 20)

# Display a negative sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("red", "gray80"),
                   max.words = 100)

# Display a positive sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("gray80", "darkgreen"),
                   max.words = 100)
################################### CAN-AM SXS END

################################### ARCTIC CAT ATV BEGIN
# Set the working directory, load the file and remove whitespace:
setwd("C:/TextAnalytics")
fileName <- trimws("sentiment_cleaned_arcat_atv.csv")

# Concatenate all posts together:
fileText <- glue(read_file(fileName))

# Remove special symbols, split data into terms and remove empty string data:
fileText <- gsub("\\$", "", fileText)
fileText = strsplit(fileText, " ")
fileText = unlist(fileText)
fileText = fileText[fileText != ""]

# Tokenize the data:
tokens = tibble(text = fileText) %>% unnest_tokens(word, text)

# Get sentiment from the text using the Hu and Liu Lexicon (reference in paper):
tokens %>%
  inner_join(get_sentiments("bing")) %>% # pull out only sentiment words
  count(sentiment) %>% # count the # of positive & negative words
  spread(sentiment, n, fill = 0) %>% # made data wide rather than narrow
  mutate(sentiment = positive / (negative + positive)) # ratio of positive

# Create a summary of positive and negative terms, display the top 20:
term_summary = tokens %>% inner_join(get_sentiments("bing")) %>% count(word, sentiment, sort = TRUE)
head(term_summary, 20)

# Display a negative sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("red", "gray80"),
                   max.words = 100)

# Display a positive sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("gray80", "darkgreen"),
                   max.words = 100)
################################### ARCTIC CAT ATV END

################################### ARCTIC CAT SXS BEGIN
# Set the working directory, load the file and remove whitespace:
setwd("C:/TextAnalytics")
fileName <- trimws("sentiment_cleaned_arcat_sxs.csv")

# Concatenate all posts together:
fileText <- glue(read_file(fileName))

# Remove special symbols, split data into terms and remove empty string data:
fileText <- gsub("\\$", "", fileText)
fileText = strsplit(fileText, " ")
fileText = unlist(fileText)
fileText = fileText[fileText != ""]

# Tokenize the data:
tokens = tibble(text = fileText) %>% unnest_tokens(word, text)

# Get sentiment from the text using the Hu and Liu Lexicon (reference in paper):
tokens %>%
  inner_join(get_sentiments("bing")) %>% # pull out only sentiment words
  count(sentiment) %>% # count the # of positive & negative words
  spread(sentiment, n, fill = 0) %>% # made data wide rather than narrow
  mutate(sentiment = positive / (negative + positive)) # ratio of positive

# Create a summary of positive and negative terms, display the top 20:
term_summary = tokens %>% inner_join(get_sentiments("bing")) %>% count(word, sentiment, sort = TRUE)
head(term_summary, 20)

# Display a negative sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("red", "gray80"),
                   max.words = 100)

# Display a positive sentiment wordcloud:
set.seed(123)
tokens %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("gray80", "darkgreen"),
                   max.words = 100)
################################### ARCTIC CAT SXS END
############################################## SENTIMENT ANALYSIS END









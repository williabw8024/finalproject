# Brent W. Williams
# DS785: Data Science Capstone
# Dr. Garland
# FORUM SCRAPING SCRIPT

###########################################################################################
# Load required libraries into memory:
library(rvest)
library(stringr)

# Create the "TextAnalytics" folder on your C: drive that will be used to store all project data
setwd("C:/")
dir.create("TextAnalytics")
setwd("C:/TextAnalytics")

# Create character variable that will hold our posts:
thread_text_total = as.character(c())

# Enter main forum page here (uncomment as needed)
# Take note of the total pages in the forum by visiting them in a browser
# I chose 200 max pages for the study:
#main_forum_url = "https://www.polarisatvforums.com/forums/atv-general-discussion.7/" #Polaris ATV, 200 pages
#main_forum_url = "https://www.rzrforums.net/forums/general-rzr-discussion.5/" #Polaris SxS, 200 pages
#main_forum_url = "https://www.can-amforum.com/forums/can-am-outlander.133/" #Can-Am ATV, 200 pages
#main_forum_url = "https://www.maverickforums.net/forums/maverick-discussions.7/" #Can-Am SxS, 182 pages
#main_forum_url = "https://www.arcticchat.com/forums/general-atv-discussion.145/" #Arctic Cat, ATV, 200 pages
main_forum_url = "https://www.wildcatforums.net/forums/wildcat-general-discussion.6/" #Arctic Cat, SxS, 165 pages

# Set this to a value to the number of pages you want to scrape (use above as guide or 1 to test):
forum_total_pages = 1

# For loop to iterate over each page and each thread on those pages, within the forum:
for (i in 1:forum_total_pages){ #Will iterate over the total pages you've designated above
  # Read each forum page in:
  forum_url = paste(main_forum_url, "page-", i, sep="")
  forum_page = read_html(forum_url)
  forum_page_message = paste("FORUM PAGE:",i, sep=" ")
  print(forum_page_message)
  
  # Extract the thread titles only:
  thread_titles <- forum_page %>% rvest::html_nodes('body') %>% #From the page, read the body section of HTML
    xml2::xml_find_all("//div[contains(@class, 'structItem-title')]") %>% #Find all instances of the class containing the thread titles
    rvest::html_text() %>% #Read thread title text in
    str_replace_all(pattern = "\n", replacement = "") %>% #Remove new line symbols from text
    str_replace_all(pattern = "Sticky", replacement = "") #Remove sticky tag for posts at top of page
  
  # This forum attaches the thread titles to a numerical code, so we'll need to extract the URLs individually
  # Get the thread URL links:
  thread_link <- forum_page %>% rvest::html_nodes("body .structItem-title a") %>% html_attr("href") %>% unique()
  
  # Single thread miner; for all threads in the thread_link variable, scrape the post contents:
  for (j in 1:length(thread_link)){ #Loop over each thread URL link
    combined_thread_text = as.character(c()) #Create a temporary thread text variable, will hold all posts from each thread
    single_thread = thread_link[j] #Access the single thread element in the current for loop
    # IMPORTANT: CHANGE THE BASE THREAD URL TO MATCH THAT OF THE FORUM YOU WANT TO SCRAPE ABOVE
    thread_url = paste("https://www.wildcatforums.net", single_thread, sep="") #Concatenate the base URL with single thread element
    
    tryCatch({
      thread_url_page = read_html(thread_url) #Read the page in, assign to variable
      
      # Find the number of pages in the thread, assign max number of pages:
      thread_pages = thread_url_page %>% html_nodes(css = ".pageNav-page") %>% html_text
      if (length(thread_pages)>0){
        thread_total_pages = max(thread_pages)
      } else {
        thread_total_pages = 1
      }
      thread_total_pages = as.integer(thread_total_pages) #Assign the total number of pages for each thread
      
      # Loop over each thread's page
      for (p in 1:thread_total_pages){
        current_url = paste(thread_url, "page-", p, sep="")
        print(current_url) #This displays the current thread page being scraped for the user
        current_url_page = read_html(current_url)
        
        # Extract the dates from each post in the thread:
        thread_dates = current_url_page %>% rvest::html_nodes("body .message-attribution-main a time") %>% html_attr("datetime")
        trimmed_dates = as.character(c()) #Create empty vector that will hold the trimmed dates
        for (d in 1:length(thread_dates)){ #Iterate over all the dates for the posts in the thread
          single_date = substr(thread_dates[d], 1, 10) #Extract only the date from datetime field
          trimmed_dates = append(trimmed_dates, single_date) #Append the extracted dates into a vector of all post dates
        }
        
        # Scrape all the posts in each thread for their discourse text
        thread_text = current_url_page %>% #New variable to contain the text of the thread
          html_nodes(css = ".message-content") %>% #For nodes that contain the posts
          html_text() %>% #Scrape them
          str_replace_all(pattern = ",", replacement = " ") %>% #Replace commas with space
          str_replace_all(pattern = "\n", replacement = " ") %>% #Replace new lines with space
          str_trim() %>% #Trim leading and trailing white space
          unique() #Return only unique posts
        
        # For each element in all the posts scraped in a single thread, concatenate the thread title with the post:
        for (k in 1:length(thread_text)){
          combined_title_post = paste(trimmed_dates[k], thread_titles[j], thread_text[k], sep = "######") #Separator for thread title and post text
          combined_thread_text = append(combined_thread_text, combined_title_post) #Append to our temporary thread text variable
        }
        thread_text_total = append(thread_text_total, combined_thread_text) #Append all the posts from this thread iteration
      } # End of thread page loop
      
    }, error=function(e){})
  }
  # End of operations for this forum page
  print("SCRAPE FINISHED!") #After all thread pages have been scraped across all forum pages, let the user know the operation is complete
}

# Save the scraped posts:
write.csv(thread_text_total, 'SxS_forum_scrape.csv') #Change as appropriate to the forum

# Remove all variables (clean up)
rm (list = ls())
gc()
cat("\014")  #clear the console
# Check the C:/TextAnalytics directory for your scrape output
###########################################################################################







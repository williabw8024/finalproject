# Brent W. Williams
# DS785: Data Science Capstone
# Dr. Garland
# FORUM TEXT CLEANING SCRIPT

###########################################################################################
################################################ PACKAGE INSTALLATIONS
# Clear the memory and console:
rm(list=ls())
gc()
cat("\014")  #clear the console

# One time installs (uncomment to install the package):
#install.packages("wordcloud")
#install.packages("RColorBrewer")
#install.packages("textmineR")
#install.packages("tidytext")
#install.packages("ggplot2")
#install.packages("tm")
#install.packages("slam")
################################################ 



################################################ FOLDER CREATION
# The C:/TextAnalytics folder should already be created if you run the forum scraping script
# Set the working directory containing the forum-scraped data:
setwd("C:/TextAnalytics/")
# IMPORTANT!!!  ENSURE THE RAW FORUM SCRAPES ARE IN THIS FOLDER  IMPORTANT!!!
################################################ 



################################################ READ IN THE SCRAPED DATA
# Read the extracted forum posts in for each brand and product:
polaris_atv_data = read.csv("Polaris_ATV_Forum_Scrape.csv")
polaris_sxs_data = read.csv("Polaris_SxS_Forum_Scrape.csv")
canam_atv_data = read.csv("CanAm_ATV_Forum_Scrape.csv")
canam_sxs_data = read.csv("CanAm_SxS_Forum_Scrape.csv")
arcat_atv_data = read.csv("ArcticCat_ATV_Forum_Scrape.csv")
arcat_sxs_data = read.csv("ArcticCat_SxS_Forum_Scrape.csv")

# Remove the row designation column for each data set (keep the date-topic-content column):
polaris_atv_data = polaris_atv_data[,2]
polaris_sxs_data = polaris_sxs_data[,2]
canam_atv_data = canam_atv_data[,2]
canam_sxs_data = canam_sxs_data[,2]
arcat_atv_data = arcat_atv_data[,2]
arcat_sxs_data = arcat_sxs_data[,2]

# Find the total number of posts 
# for each data set:
length(polaris_atv_data)
length(polaris_sxs_data)
length(canam_atv_data)
length(canam_sxs_data)
length(arcat_atv_data)
length(arcat_sxs_data)
################################################ END OF READING IN DATA



################################################ FILTER THE FORUM POSTS BY YEAR
# Extract posts made in 2018 or later:
# For Polaris ATV
ext_polaris_atv_data = as.character(c())    #create a variable to hold our extract population
for (i in 1:length(polaris_atv_data)){    #iterate over each record
  year = substr(polaris_atv_data[i],1,4)    #draw out the year from the date
  firstletter = substr(polaris_atv_data[i],1,1)    #draw out the first letter from the date
  if( firstletter == "2"){    #verification of 2nd millenium
    year = as.integer(year)    #convert character data to integer
    if( year >= 2018 ){    #check for date of post to be 2018 or later
      ext_polaris_atv_data = append(ext_polaris_atv_data, polaris_atv_data[i])    #append the post to our extract population variable
    }
  }
}

# For Polaris SxS (takes a long time to run, please be patient)
ext_polaris_sxs_data = as.character(c())    #create a variable to hold our extract population
for (i in 1:length(polaris_sxs_data)){    #iterate over each record
  year = substr(polaris_sxs_data[i],1,4)    #draw out the year from the date
  firstletter = substr(polaris_sxs_data[i],1,1)    #draw out the first letter from the date
  if( firstletter == "2"){    #verification of 2nd millenium
    year = as.integer(year)    #convert character data to integer
    if( year >= 2018 ){    #check for date of post to be 2018 or later
      ext_polaris_sxs_data = append(ext_polaris_sxs_data, polaris_sxs_data[i])    #append the post to our extract population variable
    }
  }
}

# For Can-Am ATV
ext_canam_atv_data = as.character(c())    #create a variable to hold our extract population
for (i in 1:length(canam_atv_data)){    #iterate over each record
  year = substr(canam_atv_data[i],1,4)    #draw out the year from the date
  firstletter = substr(canam_atv_data[i],1,1)    #draw out the first letter from the date
  if( firstletter == "2"){    #verification of 2nd millenium
    year = as.integer(year)    #convert character data to integer
    if( year >= 2018 ){    #check for date of post to be 2018 or later
      ext_canam_atv_data = append(ext_canam_atv_data, canam_atv_data[i])    #append the post to our extract population variable
    }
  }
}

# For Can-Am SxS
ext_canam_sxs_data = as.character(c())    #create a variable to hold our extract population
for (i in 1:length(canam_sxs_data)){    #iterate over each record
  year = substr(canam_sxs_data[i],1,4)    #draw out the year from the date
  firstletter = substr(canam_sxs_data[i],1,1)    #draw out the first letter from the date
  if( firstletter == "2"){    #verification of 2nd millenium
    year = as.integer(year)    #convert character data to integer
    if( year >= 2018 ){    #check for date of post to be 2018 or later
      ext_canam_sxs_data = append(ext_canam_sxs_data, canam_sxs_data[i])    #append the post to our extract population variable
    }
  }
}

# For Arctic Cat ATV
ext_arcat_atv_data = as.character(c())    #create a variable to hold our extract population
for (i in 1:length(arcat_atv_data)){    #iterate over each record
  year = substr(arcat_atv_data[i],1,4)    #draw out the year from the date
  firstletter = substr(arcat_atv_data[i],1,1)    #draw out the first letter from the date
  if( firstletter == "2"){    #verification of 2nd millenium
    year = as.integer(year)    #convert character data to integer
    if( year >= 2018 ){    #check for date of post to be 2018 or later
      ext_arcat_atv_data = append(ext_arcat_atv_data, arcat_atv_data[i])    #append the post to our extract population variable
    }
  }
}

# For Arctic Cat SxS
ext_arcat_sxs_data = as.character(c())    #create a variable to hold our extract population
for (i in 1:length(arcat_sxs_data)){    #iterate over each record
  year = substr(arcat_sxs_data[i],1,4)    #draw out the year from the date
  firstletter = substr(arcat_sxs_data[i],1,1)    #draw out the first letter from the date
  if( firstletter == "2"){    #verification of 2nd millenium
    year = as.integer(year)    #convert character data to integer
    if( year >= 2018 ){    #check for date of post to be 2018 or later
      ext_arcat_sxs_data = append(ext_arcat_sxs_data, arcat_sxs_data[i])    #append the post to our extract population variable
    }
  }
}

# Find the new total number of posts for each 
# data set (2018 and later threshold):
length(ext_polaris_atv_data)
length(ext_polaris_sxs_data)
length(ext_canam_atv_data)
length(ext_canam_sxs_data)
length(ext_arcat_atv_data)
length(ext_arcat_sxs_data)
################################################ END OF YEAR FILTERING



################################################ SAMPLE THE POSTS
# Because the number of posts is uneven we need to ensure
# each combination has approximately the same representation of initial post content
# Sample 4000 records and save as a new variable for each population:
set.seed(123)
samp_polaris_atv_data = sample(ext_polaris_atv_data, 4000)
samp_polaris_sxs_data = sample(ext_polaris_sxs_data, 4000)
samp_canam_atv_data = sample(ext_canam_atv_data, 4000)
samp_canam_sxs_data = sample(ext_canam_sxs_data, 4000)
samp_arcat_atv_data = sample(ext_arcat_atv_data, 4000)
samp_arcat_sxs_data = sample(ext_arcat_sxs_data, 4000)

# Ensure the post lengths for each 
# data set is 4000 records:
length(samp_polaris_atv_data)
length(samp_polaris_sxs_data)
length(samp_canam_atv_data)
length(samp_canam_sxs_data)
length(samp_arcat_atv_data)
length(samp_arcat_sxs_data)
################################################ END OF POST SAMPLING



################################################ EXTRACT THE POST'S CONTENT
# Extract only the post's content by splitting
# apart the date and topic title from the body of the post:
# For Polaris ATV
final_text_polaris_atv = as.character(c())    #create a new variable to hold the contents
for (j in 1:length(samp_polaris_atv_data)){    #iterate over each record of the 2018 extract
  split_record = strsplit(samp_polaris_atv_data[j], "######")    #split on the symbol ######
  text_from_record = split_record[[1]][3]    #extract the body of the post (may include attachments)
  split_record_attachments = strsplit(text_from_record, "Attachments")    #split attachment comments from the content
  final_text = split_record_attachments[[1]][1]    #extract the body of the post only
  final_text = gsub("\\s+", " ", final_text)    #substitute large whitespaces with a single space
  final_text_polaris_atv = append(final_text_polaris_atv, final_text)    #append our storage variable with final contents
}

# For Polaris SxS
final_text_polaris_sxs = as.character(c())    #create a new variable to hold the contents
for (j in 1:length(samp_polaris_sxs_data)){    #iterate over each record of the 2018 extract
  split_record = strsplit(samp_polaris_sxs_data[j], "######")    #split on the symbol ######
  text_from_record = split_record[[1]][3]    #extract the body of the post (may include attachments)
  split_record_attachments = strsplit(text_from_record, "Attachments")    #split attachment comments from the content
  final_text = split_record_attachments[[1]][1]    #extract the body of the post only
  final_text = gsub("\\s+", " ", final_text)    #substitute large whitespaces with a single space
  final_text_polaris_sxs = append(final_text_polaris_sxs, final_text)    #append our storage variable with final contents
}

# For Can-Am ATV
final_text_canam_atv = as.character(c())    #create a new variable to hold the contents
for (j in 1:length(samp_canam_atv_data)){    #iterate over each record of the 2018 extract
  split_record = strsplit(samp_canam_atv_data[j], "######")    #split on the symbol ######
  text_from_record = split_record[[1]][3]    #extract the body of the post (may include attachments)
  split_record_attachments = strsplit(text_from_record, "Attachments")    #split attachment comments from the content
  final_text = split_record_attachments[[1]][1]    #extract the body of the post only
  final_text = gsub("\\s+", " ", final_text)    #substitute large whitespaces with a single space
  final_text_canam_atv = append(final_text_canam_atv, final_text)    #append our storage variable with final contents
}

# For Can-Am SxS
final_text_canam_sxs = as.character(c())    #create a new variable to hold the contents
for (j in 1:length(samp_canam_sxs_data)){    #iterate over each record of the 2018 extract
  split_record = strsplit(samp_canam_sxs_data[j], "######")    #split on the symbol ######
  text_from_record = split_record[[1]][3]    #extract the body of the post (may include attachments)
  split_record_attachments = strsplit(text_from_record, "Attachments")    #split attachment comments from the content
  final_text = split_record_attachments[[1]][1]    #extract the body of the post only
  final_text = gsub("\\s+", " ", final_text)    #substitute large whitespaces with a single space
  final_text_canam_sxs = append(final_text_canam_sxs, final_text)    #append our storage variable with final contents
}

# For Arctic Cat ATV
final_text_arcat_atv = as.character(c())    #create a new variable to hold the contents
for (j in 1:length(samp_arcat_atv_data)){    #iterate over each record of the 2018 extract
  split_record = strsplit(samp_arcat_atv_data[j], "######")    #split on the symbol ######
  text_from_record = split_record[[1]][3]    #extract the body of the post (may include attachments)
  split_record_attachments = strsplit(text_from_record, "Attachments")    #split attachment comments from the content
  final_text = split_record_attachments[[1]][1]    #extract the body of the post only
  final_text = gsub("\\s+", " ", final_text)    #substitute large whitespaces with a single space
  final_text_arcat_atv = append(final_text_arcat_atv, final_text)    #append our storage variable with final contents
}

# For Arctic Cat SxS
final_text_arcat_sxs = as.character(c())    #create a new variable to hold the contents
for (j in 1:length(samp_arcat_sxs_data)){    #iterate over each record of the 2018 extract
  split_record = strsplit(samp_arcat_sxs_data[j], "######")    #split on the symbol ######
  text_from_record = split_record[[1]][3]    #extract the body of the post (may include attachments)
  split_record_attachments = strsplit(text_from_record, "Attachments")    #split attachment comments from the content
  final_text = split_record_attachments[[1]][1]    #extract the body of the post only
  final_text = gsub("\\s+", " ", final_text)    #substitute large whitespaces with a single space
  final_text_arcat_sxs = append(final_text_arcat_sxs, final_text)    #append our storage variable with final contents
}

# Write our preclean results and clean up memory:
setwd("C:/TextAnalytics")
write.csv(final_text_polaris_atv, "preclean_polaris_atv.csv")
write.csv(final_text_polaris_sxs, "preclean_polaris_sxs.csv")
write.csv(final_text_canam_atv, "preclean_canam_atv.csv")
write.csv(final_text_canam_sxs, "preclean_canam_sxs.csv")
write.csv(final_text_arcat_atv, "preclean_arcat_atv.csv")
write.csv(final_text_arcat_sxs, "preclean_arcat_sxs.csv")
rm(list=ls())
gc()
cat("\014")  #clear the console
################################################ EXTRACTION END



################################################ CLEANING EACH TEXT POPULATION
# Load the supporting libraries:
library(tm)

# Additional stopwords with which to clean text:
mystopwords = c("just","click","will","like","said","use",
                "get","one","now","see","put","got","know","don",
                "also","take","expand","didn","come","say","may",
                "seem","com","guy","can","cat","think","thank","sent")

# Create a function to load files in as a corpus:
createCorpus <- function(filepath) {
  conn <- file(filepath, "r")
  fulltext <- readLines(conn)
  close(conn)
  
  vs <- VectorSource(fulltext)
  Corpus(vs, readerControl=list(readPlain, language="en", load=TRUE))
}

# Set the working directory containing the preclean data:
setwd("C:/TextAnalytics")

################################# POLARIS ATV BEGIN
# Read in the precleaned data, merge into one vector, apply lowercase adjustment,
# remove mentions, urls, emojis, numbers and punctuation (first pass):
text = read.csv("preclean_polaris_atv.csv")
text = paste(text, collapse = " ")
text = tolower(text)
text = gsub("@\\w+", " ", text)
text = gsub("\\d+\\w*\\d*", " ", text)
text = gsub("#\\w+", " ", text)
text = gsub("[^\x01-\x7F]", " ", text)
text = gsub("[[:punct:]]", " ", text)
text = gsub("(http[^ ]*)|(www.[^ ]*)", "", text)

# Write to CSV file, reload as corpus:
write.csv(text, "cleaned_polaris_atv.csv", row.names=FALSE)
rm(text)
text = createCorpus("C:/TextAnalytics/cleaned_polaris_atv.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
polaris_atv_corpus = text
################################# POLARIS ATV END

################################# POLARIS SXS BEGIN
# Read in the precleaned data, merge into one vector, apply lowercase adjustment,
# remove mentions, urls, emojis, numbers and punctuation (first pass):
text = read.csv("preclean_polaris_sxs.csv")
text = paste(text, collapse = " ")
text = tolower(text)
text = gsub("@\\w+", " ", text)
text = gsub("\\d+\\w*\\d*", " ", text)
text = gsub("#\\w+", " ", text)
text = gsub("[^\x01-\x7F]", " ", text)
text = gsub("[[:punct:]]", " ", text)
text = gsub("(http[^ ]*)|(www.[^ ]*)", "", text)

# Write to CSV file, reload as corpus:
write.csv(text, "cleaned_polaris_sxs.csv", row.names=FALSE)
rm(text)
text = createCorpus("C:/TextAnalytics/cleaned_polaris_sxs.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
polaris_sxs_corpus = text
################################# POLARIS SXS END

################################# CAN-AM ATV BEGIN
# Read in the precleaned data, merge into one vector, apply lowercase adjustment,
# remove mentions, urls, emojis, numbers and punctuation (first pass):
text = read.csv("preclean_canam_atv.csv")
text = paste(text, collapse = " ")
text = tolower(text)
text = gsub("@\\w+", " ", text)
text = gsub("\\d+\\w*\\d*", " ", text)
text = gsub("#\\w+", " ", text)
text = gsub("[^\x01-\x7F]", " ", text)
text = gsub("[[:punct:]]", " ", text)
text = gsub("(http[^ ]*)|(www.[^ ]*)", "", text)

# Write to CSV file, reload as corpus:
write.csv(text, "cleaned_canam_atv.csv", row.names=FALSE)
rm(text)
text = createCorpus("C:/TextAnalytics/cleaned_canam_atv.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
canam_atv_corpus = text
################################# CAN-AM ATV END

################################# CAN-AM SXS BEGIN
# Read in the precleaned data, merge into one vector, apply lowercase adjustment,
# remove mentions, urls, emojis, numbers and punctuation (first pass):
text = read.csv("preclean_canam_sxs.csv")
text = paste(text, collapse = " ")
text = tolower(text)
text = gsub("@\\w+", " ", text)
text = gsub("\\d+\\w*\\d*", " ", text)
text = gsub("#\\w+", " ", text)
text = gsub("[^\x01-\x7F]", " ", text)
text = gsub("[[:punct:]]", " ", text)
text = gsub("(http[^ ]*)|(www.[^ ]*)", "", text)

# Write to CSV file, reload as corpus:
write.csv(text, "cleaned_canam_sxs.csv", row.names=FALSE)
rm(text)
text = createCorpus("C:/TextAnalytics/cleaned_canam_sxs.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
canam_sxs_corpus = text
################################# CAN-AM SXS END

################################# ARCTIC CAT ATV BEGIN
# Read in the precleaned data, merge into one vector, apply lowercase adjustment,
# remove mentions, urls, emojis, numbers and punctuation (first pass):
text = read.csv("preclean_arcat_atv.csv")
text = paste(text, collapse = " ")
text = tolower(text)
text = gsub("@\\w+", " ", text)
text = gsub("\\d+\\w*\\d*", " ", text)
text = gsub("#\\w+", " ", text)
text = gsub("[^\x01-\x7F]", " ", text)
text = gsub("[[:punct:]]", " ", text)
text = gsub("(http[^ ]*)|(www.[^ ]*)", "", text)

# Write to CSV file, reload as corpus:
write.csv(text, "cleaned_arcat_atv.csv", row.names=FALSE)
rm(text)
text = createCorpus("C:/TextAnalytics/cleaned_arcat_atv.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
arcat_atv_corpus = text
################################# ARCTIC CAT ATV END

################################# ARCTIC CAT SXS BEGIN
# Read in the precleaned data, merge into one vector, apply lowercase adjustment,
# remove mentions, urls, emojis, numbers and punctuation (first pass):
text = read.csv("preclean_arcat_sxs.csv")
text = paste(text, collapse = " ")
text = tolower(text)
text = gsub("@\\w+", " ", text)
text = gsub("\\d+\\w*\\d*", " ", text)
text = gsub("#\\w+", " ", text)
text = gsub("[^\x01-\x7F]", " ", text)
text = gsub("[[:punct:]]", " ", text)
text = gsub("(http[^ ]*)|(www.[^ ]*)", "", text)

# Write to CSV file, reload as corpus:
write.csv(text, "cleaned_arcat_sxs.csv", row.names=FALSE)
rm(text)
text = createCorpus("C:/TextAnalytics/cleaned_arcat_sxs.csv")

# Final document preparations
# Remove stopwords, perform stemming, remove extra whitespace
# Note: warning messages are normal!:
text = tm_map(text, stripWhitespace)
text = tm_map(text, stemDocument)
text = tm_map(text, removeWords, stopwords("english"))
text = tm_map(text, removeWords, mystopwords)   #clean with additional stopwords
text = tm_map(text, removePunctuation)  #remove punctuation introduced by above operations
arcat_sxs_corpus = text
################################# ARCTIC CAT SXS END
################################################ CLEANING END



################################################ SIMPLE DESCRIPTIVE STATISTICS & WORD FREQUENCIES
# Load supporting libraries:
library(tm)
library(ggplot2)

################################# POLARIS ATV BEGIN
# Create a document-term matrix where each document is a post:
dtm = DocumentTermMatrix(polaris_atv_corpus)

# Number of unique words in the corpus:
freq = colSums(as.matrix(dtm))   
length(freq)

# Calculate word frequency and display the top 20 words of the corpus:
freq = sort(colSums(as.matrix(dtm)), decreasing=TRUE)   
wf = data.frame(Term = names(freq), Count = freq)   
head(wf, 20)

# Calculate the total number of words in the corpus:
sum(wf$Count)

# Plot the word frequencies of words mentioned over 500 times across the sampled posts:
plot = ggplot(subset(wf, freq>500), aes(x = reorder(Term, -Count), y = Count)) +
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle=45, hjust=1)) +
  geom_text(aes(label=Count), position=position_dodge(width=0.9), vjust=-0.25) +
  xlab("Word") +
  theme(axis.text.x = element_text(size = 18)) +
  ylim(0,1000)

plot
################################# POLARIS ATV END

################################# POLARIS SXS BEGIN
# Create a document-term matrix where each document is a post:
dtm = DocumentTermMatrix(polaris_sxs_corpus)

# Number of unique words in the corpus:
freq = colSums(as.matrix(dtm))   
length(freq)

# Calculate word frequency and display the top 20 words of the corpus:
freq = sort(colSums(as.matrix(dtm)), decreasing=TRUE)   
wf = data.frame(Term = names(freq), Count = freq)   
head(wf, 20)

# Calculate the total number of words in the corpus:
sum(wf$Count)

# Plot the word frequencies of words mentioned over 500 times across the sampled posts:
plot = ggplot(subset(wf, freq>500), aes(x = reorder(Term, -Count), y = Count)) +
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle=45, hjust=1)) +
  geom_text(aes(label=Count), position=position_dodge(width=0.9), vjust=-0.25) +
  xlab("Word") +
  theme(axis.text.x = element_text(size = 18)) +
  ylim(0,1000)

plot
################################# POLARIS SXS END

################################# CAN-AM ATV BEGIN
# Create a document-term matrix where each document is a post:
dtm = DocumentTermMatrix(canam_atv_corpus)

# Number of unique words in the corpus:
freq = colSums(as.matrix(dtm))   
length(freq)

# Calculate word frequency and display the top 20 words of the corpus:
freq = sort(colSums(as.matrix(dtm)), decreasing=TRUE)   
wf = data.frame(Term = names(freq), Count = freq)   
head(wf, 20)

# Calculate the total number of words in the corpus:
sum(wf$Count)

# Plot the word frequencies of words mentioned over 500 times across the sampled posts:
plot = ggplot(subset(wf, freq>500), aes(x = reorder(Term, -Count), y = Count)) +
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle=45, hjust=1)) +
  geom_text(aes(label=Count), position=position_dodge(width=0.9), vjust=-0.25) +
  xlab("Word") +
  theme(axis.text.x = element_text(size = 18)) +
  ylim(0,1000)

plot
################################# CAN-AM ATV END

################################# CAN-AM SXS BEGIN
# Create a document-term matrix where each document is a post:
dtm = DocumentTermMatrix(canam_sxs_corpus)

# Number of unique words in the corpus:
freq = colSums(as.matrix(dtm))   
length(freq)

# Calculate word frequency and display the top 20 words of the corpus:
freq = sort(colSums(as.matrix(dtm)), decreasing=TRUE)   
wf = data.frame(Term = names(freq), Count = freq)   
head(wf, 20)

# Calculate the total number of words in the corpus:
sum(wf$Count)

# Plot the word frequencies of words mentioned over 500 times across the sampled posts:
plot = ggplot(subset(wf, freq>500), aes(x = reorder(Term, -Count), y = Count)) +
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle=45, hjust=1)) +
  geom_text(aes(label=Count), position=position_dodge(width=0.9), vjust=-0.25) +
  xlab("Word") +
  theme(axis.text.x = element_text(size = 18)) +
  ylim(0,1000)

plot
################################# CAN-AM SXS END

################################# ARCTIC CAT ATV BEGIN
# Create a document-term matrix where each document is a post:
dtm = DocumentTermMatrix(arcat_atv_corpus)

# Number of unique words in the corpus:
freq = colSums(as.matrix(dtm))   
length(freq)

# Calculate word frequency and display the top 20 words of the corpus:
freq = sort(colSums(as.matrix(dtm)), decreasing=TRUE)   
wf = data.frame(Term = names(freq), Count = freq)   
head(wf, 20)

# Calculate the total number of words in the corpus:
sum(wf$Count)

# Plot the word frequencies of words mentioned over 500 times across the sampled posts:
plot = ggplot(subset(wf, freq>500), aes(x = reorder(Term, -Count), y = Count)) +
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle=45, hjust=1)) +
  geom_text(aes(label=Count), position=position_dodge(width=0.9), vjust=-0.25) +
  xlab("Word") +
  theme(axis.text.x = element_text(size = 18)) +
  ylim(0,1000)

plot
################################# ARCTIC CAT ATV END

################################# ARCTIC CAT SXS BEGIN
# Create a document-term matrix where each document is a post:
dtm = DocumentTermMatrix(arcat_sxs_corpus)

# Number of unique words in the corpus:
freq = colSums(as.matrix(dtm))   
length(freq)

# Calculate word frequency and display the top 20 words of the corpus:
freq = sort(colSums(as.matrix(dtm)), decreasing=TRUE)   
wf = data.frame(Term = names(freq), Count = freq)   
head(wf, 20)

# Calculate the total number of words in the corpus:
sum(wf$Count)

# Plot the word frequencies of words mentioned over 500 times across the sampled posts:
plot = ggplot(subset(wf, freq>500), aes(x = reorder(Term, -Count), y = Count)) +
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle=45, hjust=1)) +
  geom_text(aes(label=Count), position=position_dodge(width=0.9), vjust=-0.25) +
  xlab("Word") +
  theme(axis.text.x = element_text(size = 18)) +
  ylim(0,1000)

plot
################################# ARCTIC CAT SXS END
################################################ SIMPLE STATS END






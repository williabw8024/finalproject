# Brent W. Williams
# DS785: Data Science Capstone
# Dr. Garland
# TWITTER TWEET EXTRACTION

# One time install:
# install.packages("rtweet")
# Load the supporting library:
library(rtweet)


#################
### IN ORDER TO HARVEST TWEETS YOU NEED A TWITTER DEVELOPER ACCOUNT
### REQUEST ACCESS HERE: https://developer.twitter.com/en/apply-for-access
#################

# First set the working directory:
setwd("C:/TextAnalytics")

# Enter your Twitter developer account details below
# This includes:
# consumer_key
# consumer_secret
# access_token
# access_secret
# For purposes of script dissemination, these details have been omitted below (paste in your details):
twitter_token = create_token(app = "mytwitterapp",
                              consumer_key = '', 
                              consumer_secret = '',
                              access_token = '',
                              access_secret = '',
                              set_renv = TRUE)

################################################ CAPTURE TWITTER TWEETS
##########################
### ATV
# Include reTweets set to false:
ATV_tweets = search_tweets("ATV", n = 20000, include_rts = FALSE, lang = "en")
# Remove retweets and replies, we want the organic tweets, not duplicates of what was already posted
ATV_organic = ATV_tweets[ATV_tweets$is_retweet == FALSE, ] #select only the original tweet
ATV_organic = subset(ATV_organic, is.na(ATV_organic$reply_to_status_id)) #remove duplicates; for situations when tweet is duplicated in reply
ATV_organic = subset(ATV_organic, select = c("status_id", "text", "location", "created_at"))
# Save the scraped posts:
write.csv(ATV_organic, 'ATV_tweets.csv')
##########################

##########################
### SxS
# Include reTweets set to false:
SxS_tweets = search_tweets("SxS", n = 20000, include_rts = FALSE, lang = "en")
# Remove retweets and replies, we want the organic tweets, not duplicates of what was already posted
SxS_organic = SxS_tweets[SxS_tweets$is_retweet == FALSE, ] #select only the original tweet
SxS_organic = subset(SxS_organic, is.na(SxS_organic$reply_to_status_id)) #remove duplicates; for situations when tweet is duplicated in reply
SxS_organic = subset(SxS_organic, select = c("status_id", "text", "location", "created_at"))
# Save the scraped posts:
write.csv(SxS_organic, 'SxS_tweets.csv')
##########################

##########################
### Polaris
# Include reTweets set to false:
Polaris_tweets = search_tweets(q = "polaris", n = 20000, include_rts = FALSE, lang = "en")
# Remove retweets and replies, we want the organic tweets, not duplicates of what was already posted
Polaris_organic = Polaris_tweets[Polaris_tweets$is_retweet == FALSE, ] #select only the original tweet
Polaris_organic = subset(Polaris_organic, is.na(Polaris_organic$reply_to_status_id)) #remove duplicates; for situations when tweet is duplicated in reply
Polaris_organic = subset(Polaris_organic, select = c("status_id", "text", "location", "created_at"))
# Save the scraped posts:
write.csv(Polaris_organic, 'Polaris_tweets.csv')
##########################


##########################
### UTV
# Include reTweets set to false:
UTV_tweets = search_tweets("UTV", n = 20000, include_rts = FALSE, lang = "en")
# Remove retweets and replies, we want the organic tweets, not duplicates of what was already posted
UTV_organic = UTV_tweets[UTV_tweets$is_retweet == FALSE, ] #select only the original tweet
UTV_organic = subset(UTV_organic, is.na(UTV_organic$reply_to_status_id)) #remove duplicates; for situations when tweet is duplicated in reply
UTV_organic = subset(UTV_organic, select = c("status_id", "text", "location", "created_at"))
# Save the scraped posts:
write.csv(UTV_organic, 'UTV_tweets.csv')
##########################
################################################ END OF TWEET CAPTURE





